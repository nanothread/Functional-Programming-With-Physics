import PlaygroundSupport
/*:
 # Functional Programming with Physics
 
 Welcome! This playground helps you explore basic functional programming principles using a physics simulation.
 
 - Note: Any 'not in scope' errors should go away after a few seconds!
 
 ## Using Filter
 
 Given an array of numbers, let's say we want to make another array containing **only the even elements**. Using imperative programming, we might write:
*/
let input = [4,5,2,6,1,2,3]
var forLoopResult = [Int]()
for element in input where element.isMultiple(of: 2) {
    forLoopResult.append(element)
}
forLoopResult
/*:
 This imperative code gets the job done, but it's a little verbose. We could instead use `.filter` to
 to solve the problem faster:
*/
let filterResult = input.filter { $0.isMultiple(of: 2) }
filterResult
/*:
 We still get `[4,2,6,2]`, but how? Run the code below to see how it works.
 
 - Important: Open the live view and click the **Next Value** button every few seconds. If the values are difficult to discern, try toggling *Rotation* to off.
*/
PlaygroundPage.current.setLiveView(
    Simulation(
        source: input,
        pipeline: [
            Filter(expression: "input is even")
        ]
    )
)
/*:
 We're left with the values `[4,2,6,2]`! As you can see, the contents of the closure is run for every individual element in the input array, and
 the result (return value) of the closure is used to decide whether the element is allowed through or not.
*/
/*:
 ## Using Map
 
 Now let's say we want to create a new array containing the **squares of the numbers** in the input array. Similarly, instead of building our result in a for loop, we can execute a transformation using `map`:
*/
let mapResult = input.map { $0 * $0 }
mapResult

PlaygroundPage.current.setLiveView(
    Simulation(
        source: input,
        pipeline: [
            Map(expression: "input x input")
        ]
    )
)
/*:
 In this case, the result of the closure becomes an element in the result array.
*/
//: [Putting it All Together -->](@next)


