import PlaygroundSupport
//: [<-- Introduction](@previous)
/*: ## Putting it All Together
 
 You can combine `map` and `filter` to solve complex problems. Run the simulations to see how the functional solutions work!
*/
// Generate 7 random numbers (no duplicates)
let input = (1...10).shuffled().prefix(7)
input
//: ### 1. Get half of all the even numbers
let result1 = input
    .filter { $0.isMultiple(of: 2) }
    .map { $0 / 2 }
result1

PlaygroundPage.current.setLiveView(
    Simulation(
        source: input,
        pipeline: [
            Filter(expression: "input is even"),
            Map(expression: "input ÷ 2")
        ]
    )
)
//: ### 2. Find the numbers that are one more than a prime number
let result2 = input
    .map { $0 - 1 }
    .filter { $0.isPrime() }
    .map { $0 + 1 }
result2

PlaygroundPage.current.setLiveView(
    Simulation(
        source: input,
        pipeline: [
            Map(expression: "input - 1"),
            Filter(expression: "input is prime"),
            Map(expression: "input + 1"),
        ]
    )
)
//: - Experiment: Do we really need those `map` functions? How could we get rid of them but still end up with the same values?
/*: ### 3. Double check a magic trick!
 The trick is...
 1. Choose a number between 1 and 8
 2. Multiply by 2
 3. Multiply by 5
 4. Subtract 5
 5. Add 7
 
 Now look at the result: the first digit is the number you chose, and the second digit will be 2. [(Source)](https://www.risingstars-uk.com/blog/march-2018/blog-march-2018-magic-maths-blog?feed=rising-stars-blog)
 
 **Run the simulation to try it out!**
*/
PlaygroundPage.current.setLiveView(
    Simulation(
        source: input,
        pipeline: [
            Filter(expression: "input <= 8"),
            Map(expression: "input x 2"),
            Map(expression: "input x 5"),
            Map(expression: "input - 5"),
            Map(expression: "input + 7")
        ]
    )
)
//: - Experiment: Now you've seen the trick in action, try combining `map` and `filter` to build an array of values in code! You should end up with the same values that are at the bottom of the simulation.
let result3 = input
    .filter { $0 <= 8 }
    // Keep it going!

result3

/*: ## What Next?
 
 There are many more functions other than `map` and `filter` which you can use, and they work on any Swift sequence--not just arrays of integers! Check out `reduce` and `sorted` in the Swift docs.
*/
